<?php
 // Inclusion de la bibliothèque de fonctions :
 require('lib/fonctionsLivre.php');
 
 // Lecture  du fichier et mémorisation dans des variables PHP :
 $file = fopen('data/livres.txt','r');
 $biblio = libraryToHTML($file);
 
 // inclusion de la page template :
 require('views/bibliotheque.php');
?>