<?php 
   global $htmlBiblio;
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Bibliothèque</title>
        <meta charset="UTF-8" />
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <header>
            <h1>Bibliothèque</h1>
        </header>
        <?php
          echo $htmlBiblio; 
        ?>
    </body>
    
</html>